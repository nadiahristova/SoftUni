﻿using System;
using System.Threading;
using System.Globalization;


        class _03_CirclePerimeterAndArea
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            Console.Write("Please enter the radius of the circle: ");
            float r = float.Parse(Console.ReadLine());
            Console.WriteLine("Circle's perimeter is: {0,3:f2}, and it's Area is {1,3:f2}", 2 * Math.PI * r, (Math.Pow(r, 2) * Math.PI));
        }
    }

