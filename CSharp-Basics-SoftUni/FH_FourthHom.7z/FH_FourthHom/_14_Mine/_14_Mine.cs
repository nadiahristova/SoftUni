﻿using System;
using System.Collections.Generic;


class _14_Mine
{
    static void Main()
    {
        string initialStrInput = Console.ReadLine();
        short firstPositionNum = 0;
        short numberLength = -1;

        List<int> nums = new List<int>();
        for (short i = 0; i < initialStrInput.Length; i++)
        {
            if (initialStrInput[i] == ' ')
            {
                firstPositionNum = (short)(numberLength + firstPositionNum + 1);
                numberLength = (short)(i - firstPositionNum);
                nums.Add(Convert.ToInt32(initialStrInput.Substring(firstPositionNum, numberLength)));
            }

        }

        nums.Add(Convert.ToInt32(initialStrInput.Substring(firstPositionNum + numberLength + 1, initialStrInput.Length - firstPositionNum - numberLength - 1)));

        int primarySum = 0;
        foreach (var num in nums)
        {
            primarySum = primarySum + num;
        }
        int count = nums.Count;
        int theNumber = 0;
        int sum = 0;
        int diff = primarySum - 2 * nums[0];
        bool find = false;
        for (int i = 0; i < count; i++)
        {
            sum = primarySum - nums[i];
            if (nums[i] == sum)
            {
                theNumber = nums[i];
                find = true;
                break;
            }
            else
            {
                if (diff > sum)
                {
                    diff = Math.Abs(sum - nums[i]);
                    theNumber = nums[i];
                }

            }

        }


        if (find)
        {
            Console.WriteLine("Yes, sum=" + sum);
        }
        else
        {
            Console.WriteLine("No, diff=" + diff);
        }
    }
}

