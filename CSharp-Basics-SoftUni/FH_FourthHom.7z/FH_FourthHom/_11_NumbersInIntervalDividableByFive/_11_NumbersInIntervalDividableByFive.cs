﻿using System; 

    class _11_NumbersInIntervalDividableByFive
    {
        static void Main()
        {
            Console.Write("Please insert the starting number: ");
            int start = int.Parse(Console.ReadLine());
            Console.Write("Please insert the ending number: ");
            int end = int.Parse(Console.ReadLine());
            byte diff = (byte)(start % 5);
            diff =(byte) (5 - diff);
            int current=diff+start;
            Console.Write("{0} - times. As follows: ", (end / 5 - start / 5));
            for (int i = 0; i < (end/5 - start/5); i++)
            {
                Console.Write(current + " ");
                current = current + 5;
            }
            Console.WriteLine();
        }
    }

