﻿using System;
using System.Threading;
using System.Globalization;


    class _04_NumberComparer
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            Console.Write("Please insert the first number: ");
            float a = float.Parse(Console.ReadLine());
            Console.Write("Please insert the first number: ");
            float  b = float.Parse(Console.ReadLine());
            switch (a>=b)
            {
                case true: Console.WriteLine(a); break;
                case false: Console.WriteLine(b); break;
            }
        }
    }

