﻿using System;


    class _16_MagicStrings_theirVersion
    {
        static void Main()
        {
            byte diff = byte.Parse(Console.ReadLine());              
            char[] charSequence = { 'k', 'n', 'p', 's' };
            int countResults = 0;
            for (int i = 0; i < charSequence.Length; i++)
            {
                for (int j = 0; j < charSequence.Length; j++)
                {
                    for (int w = 0; w < charSequence.Length; w++)
                    {
                        for (int q = 0; q < charSequence.Length; q++)
                        {
                            string leftSum = "" + charSequence[i] + charSequence[j] + charSequence[w] + charSequence[q];
                            int sum = Transform(leftSum);
                            for (int i1 = 0; i1 < charSequence.Length; i1++)
                            {
                                for (int j1 = 0; j1 < charSequence.Length; j1++)
                                {
                                    for (int w1 = 0; w1 < charSequence.Length; w1++)
                                    {
                                        for (int q1 = 0; q1 < charSequence.Length; q1++)
                                        {
                                            string rightSum = "" + charSequence[i1] + charSequence[j1] + charSequence[w1] + charSequence[q1];
                                            int rSum = Transform(rightSum);
                                            if ((Math.Abs(rSum-sum))==diff)
                                            {
                                                Console.WriteLine(leftSum+rightSum);
                                                countResults++;
                                            }
                                            
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if(countResults==0)
            {
                Console.WriteLine("No");
            }
        }

        private static int Transform(string someSum)
        {
            int result=0;
            foreach (var ch in someSum)
            {
               switch (ch)
               {
                   case 's': result = result + 3; break;
                   case 'n': result = result + 4; break;
                   case 'k': result++; break;
                   case 'p': result = result + 5; break; 
               } 
            }
            return result;
        }
    }

