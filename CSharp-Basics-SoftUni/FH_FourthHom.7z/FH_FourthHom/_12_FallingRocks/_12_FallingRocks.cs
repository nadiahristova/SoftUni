﻿using System;
using System.Threading;


class _12_FallingRocks
{
    static void Main()
    {
        //bool gameOver = false;
        //Console.WindowHeight = 50;
        //Console.WindowWidth = 100;
        //byte index;
        //char[] rocks = new char[] { '^', '@', '*', '&', '+', '%', '$', '#', '!', '.', ';', '-' };
        //string[] colors = new string[] {"Black","DarkBlue","DarkGreen", "DarkCyan", "DarkRed", "DarkMagneta", 
        //    "DarkYellow", "Gray", "Yellow", "White"};
        //short[] speerVariation = new short[] { -250, -200, -150, -100, -50, 0, 50, 100, 150, 200, 250 };
        //byte level = 1;


        //for (int i = 0; i < 5; i++)
        //{
        //    Console.WriteLine("Sleep for 2 seconds.");
        //    Thread.Sleep(150);
        //}
        //Console.CursorVisible = false;
        //int counter = 0;
        //while (counter < 50)
        //{
        //    counter++;
        //    Thread.Sleep(1000);
        //    Console.WriteLine(counter);
        //    if (counter == 5) break;
        //    {
                
        //    }
        //}

        Random randomGen = new Random();
        
        while (true)
        {
            int cifra = randomGen.Next(1, 5);
            Console.WriteLine(cifra);
            Thread.Sleep(150);  
        }
       
       
    }
}





    //string f = "Cyan";
    //string b = "Gray";
    //Type type = typeof(ConsoleColor);
    //Console.BackgroundColor = (ConsoleColor)Enum.Parse(type, b);
    //Console.ForegroundColor = (ConsoleColor)Enum.Parse(type, f);
    //Console.Write(f+ " " + b);
    //Console.ResetColor();
    //Console.WriteLine(f + " " + b);










//using System;

//class Program
//{
//    static void Main()
//    {
//        //
//        // This program demonstrates all colors and backgrounds.
//        //
//        Type type = typeof(ConsoleColor);
//        Console.ForegroundColor = ConsoleColor.White;
//        foreach (var name in Enum.GetNames(type))
//        {
//            Console.BackgroundColor = (ConsoleColor)Enum.Parse(type, name);
//            Console.WriteLine(name);
//        }
//        Console.BackgroundColor = ConsoleColor.Black;
//        foreach (var name in Enum.GetNames(type))
//        {
//            Console.ForegroundColor = (ConsoleColor)Enum.Parse(type, name);
//            Console.WriteLine(name);
//        }
//    }
//}
