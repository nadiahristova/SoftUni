﻿using System;

    class _15_NewHouse
    {
        static void Main()
        {
            short inputOddNum = short.Parse(Console.ReadLine());             
            short helpOddNum=(short)(inputOddNum/2);
            for (int i = 1; i <= inputOddNum; i=i+2)
            {
                string roof = new string('-', helpOddNum);
                roof = roof + new string('*', i) + roof;
                Console.WriteLine(roof);
                helpOddNum = (short)(helpOddNum - 1);
            }
            for (int i = 0; i < inputOddNum; i++)
            {
                string wall = "|" + new string('*', inputOddNum - 2) + "|";
                Console.WriteLine(wall);
            }
        }
    }

