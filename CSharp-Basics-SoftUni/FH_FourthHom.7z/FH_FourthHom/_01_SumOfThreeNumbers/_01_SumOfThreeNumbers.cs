﻿using System;
using System.Threading;
using System.Globalization;
 

    class _01_SumOfThreeNumbers
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            float a, b, c;
            Console.Write("Please type in the first number: ");
            a = float.Parse(Console.ReadLine());
            Console.Write("Please type in the second number: ");
            b = float.Parse(Console.ReadLine());
            Console.Write("Please type in the second number: ");
            c = float.Parse(Console.ReadLine());
            Console.WriteLine("a+b+c={0}", a + b+c);
        }
    }

