﻿using System;
                 
    class _13_Work_Hours
    {
        static void Main()
        {
            //Console.Write("Please insert the required hours needed to finish the projest: ");
            int h = int.Parse(Console.ReadLine());
            //Console.Write("Please insert the days available to finish the projest: ");
            double d = int.Parse(Console.ReadLine());
            //Console.Write("Please insert Lelia Vanche's productivity \\in percent\\: ");
            byte p = byte.Parse(Console.ReadLine());

            d = d * 9 / 10.0;
            int pureWork =(int)( d * 12*p/100);
            
            if (h<=pureWork)
            {
                Console.WriteLine("Yes");
            }
            else Console.WriteLine("No");
            h = Convert.ToInt32(pureWork) - h;
            Console.WriteLine(h);
        }
    }

