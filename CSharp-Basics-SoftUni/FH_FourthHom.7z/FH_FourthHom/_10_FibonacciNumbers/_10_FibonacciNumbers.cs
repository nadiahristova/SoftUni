﻿using System;



    class _10_FibonacciNumbers
    {
        static void Main()
        {
            int n, Fn, Fn1, Fn2;
            Fn1 = 1;
            Fn2 = 0;
            Console.Write("Please insert how many numbers of the Fibonacci sequence u want to be shown: ");
            n = int.Parse(Console.ReadLine());
            Fn = 0;
            for (int i = 1; i <= n; i++)
            {
                Fn2 = Fn1;
                Fn1 = Fn;
                Console.Write(Fn+ "  ");
                Fn = Fn1 + Fn2;                 

            }
            Console.WriteLine();
        }
    }

