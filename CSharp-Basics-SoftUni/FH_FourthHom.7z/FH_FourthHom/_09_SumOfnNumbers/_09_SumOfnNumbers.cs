﻿using System;
using System.Threading;
using System.Globalization;

    class _09_SumOfnNumbers
    {       
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            double sum = 0,num =0;
            bool isNum = false; 
            Console.Write( "Please enter the number: ");
            int n = int.Parse(Console.ReadLine());
            
            for (int i = 1; i <= n; i++)
            {
                
                Console.Write("Enter {0}-th number : ",i);
                isNum = double.TryParse(Console.ReadLine(), out num);
                
                while (!isNum)
                {
                  Console.Write("U haven't entered a proper number. Please try again: ");
                    isNum = double.TryParse(Console.ReadLine(), out num);  
                }
              
                sum = sum + num;                                
                                 
            }
            Console.WriteLine(sum);
        }
    }

