﻿using System;
using System.Threading;
using System.Globalization;



    class _07_SumOfFiveNumbers
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            Console.Write("Please enter the sequence of the numbers: ");
            byte chCode; 
            string number= null;
            double sum = 0;
            char ch;
            do
            {
                chCode = (byte)Console.Read();
                switch (chCode)
                {
                    case 32: sum = sum + double.Parse(number); number = null;  break;
                    case 13: sum = sum + double.Parse(number); break;
                    default: {
                        ch = (char)chCode;
                        number = number + ch; 
                    }
                        break;
                }   
            } while (chCode != 13);
            Console.WriteLine(sum);
        }
    }

