﻿using System;
using System.Collections.Generic;


    class _14_SumOfElements
    {
        static void Main()
        {
            string initialStrInput = Console.ReadLine();
            short firstPositionNum = 0;
            short numberLength = -1;

            List<int> nums = new List<int>();
            for (short i = 0; i < initialStrInput.Length; i++)
            {
                if (initialStrInput[i] == ' ')
                {
                    firstPositionNum = (short)(numberLength + firstPositionNum + 1);
                    numberLength =(short)(i - firstPositionNum);
                    nums.Add(Convert.ToInt32(initialStrInput.Substring(firstPositionNum, numberLength)));
                }

            }

            nums.Add(Convert.ToInt32(initialStrInput.Substring(firstPositionNum + numberLength+1, initialStrInput.Length - firstPositionNum-numberLength - 1)));

            int count = nums.Count;
            int sum = 0;
            int max = nums[0];
            for (int i = 0; i < count; i++)
            {
                sum = sum + nums[i];
                if (nums[i]>max)
                {
                    max = nums[i];
                } 
            }
                if (2*max == sum)
                {                       
                    Console.WriteLine("Yes, sum=" + max);                    
                }
                else
                {
                   Console.WriteLine("No, diff=" + Math.Abs(sum-2*max));                     
                }      
                
            }
                           
      }

