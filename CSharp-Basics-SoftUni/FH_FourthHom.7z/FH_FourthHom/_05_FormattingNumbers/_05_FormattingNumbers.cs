﻿using System;
using System.Threading;
using System.Globalization;


    class _05_FormattingNumbers
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
            Console.Write("Please insert the first number: ");
            //string aInitial = ;
            ushort a = ushort.Parse(Console.ReadLine());
            Console.Write("Please insert the second number: ");
            float b = float.Parse(Console.ReadLine());
            Console.Write("Please insert the third number: ");
            float c = float.Parse(Console.ReadLine());
            Console.WriteLine("|{0,-10:x}|{1:d10}|{2,10:f2}|{3,-10:f3}|",a, (Convert.ToString(a,2)).PadLeft(10,'0'), b, c);
        }
    }
