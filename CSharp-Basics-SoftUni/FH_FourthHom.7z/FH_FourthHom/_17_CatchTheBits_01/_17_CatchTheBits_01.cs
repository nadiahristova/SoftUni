﻿using System;

class CatchTheBits
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        int step = int.Parse(Console.ReadLine());

        int outputNumber = 0;
        int bitCounter = 0;
        int index = 0;

        for (int i = 0; i < n; i++)
        {
            int number = int.Parse(Console.ReadLine());
            for (int bitIndex = 7; bitIndex >= 0; bitIndex--)
            {
                if ((index % step == 1) || (step == 1 & (index != 0)))
                {
                    int bitValue = (number >> bitIndex) & 1;
                    outputNumber = outputNumber << 1;
                    outputNumber = outputNumber | bitValue;
                    bitCounter++;
                    if (bitCounter == 8)
                    {
                        Console.WriteLine(outputNumber);
                        bitCounter = 0;
                        outputNumber = 0;
                    }
                }
                index++;
            }
        }
        if (bitCounter != 0)
        {
            outputNumber = outputNumber << (8 - bitCounter);
            Console.WriteLine(outputNumber);
        }
    }
}
