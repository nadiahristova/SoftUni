﻿using System;



    class _02_PrintCompanyInformation
    {
        static void Main()
        {
    Console.WriteLine("Please insurt company's name: ");
    string companyName = Console.ReadLine();
    Console.WriteLine("Please insurt company's address: ");
    string companyAddress = Console.ReadLine();
    Console.WriteLine("Please insurt company's phone number: ");
    string companyPhoneNumber = Console.ReadLine();
    Console.WriteLine("Please insurt company's fax number: ");
    long companyFaxNumber = long.Parse(Console.ReadLine());
    Console.WriteLine("Please insurt company's web site: ");
    string companyWebSite = Console.ReadLine();
    Console.WriteLine("Please insurt manager's first name: ");
    string managerFirstName = Console.ReadLine();
    Console.WriteLine("Please insurt manager's second name: ");
    string managerSecondName = Console.ReadLine();
    Console.WriteLine("Please insurt manager's age: ");
    byte managerAge = byte.Parse(Console.ReadLine());
    Console.WriteLine("Please insurt manager's phone number: ");
    string managerPhoneNumber = Console.ReadLine();
    Console.WriteLine(
			" {0}  \r\n Adress: {1} \r\n Tel. {2} \r\n Fax: {3} \r\n Web site: {4} \r\n Manager: {5} {6}(age: \r\n {7}, tel. {8})",
		companyName, companyAddress, companyPhoneNumber, companyFaxNumber, companyWebSite, managerFirstName, managerSecondName, managerAge, managerPhoneNumber);
        }
    }

