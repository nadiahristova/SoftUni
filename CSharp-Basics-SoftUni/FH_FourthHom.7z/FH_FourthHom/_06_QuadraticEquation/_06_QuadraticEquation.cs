﻿using System;
using System.Threading;
using System.Globalization;


    class _06_QuadraticEquation
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            double a,b,c,diskriminanta;

            Console.Write("Please insert a: ");
            bool isa = double.TryParse(Console.ReadLine(), out a);
            Console.Write("Please insert b: ");
            bool isb = double.TryParse(Console.ReadLine(), out b);
            Console.Write("Please insert c: ");
            bool isc = double.TryParse(Console.ReadLine(), out c);
            
            if (isa&&isb&&isc)
            {
                diskriminanta = Math.Pow(b, 2) - 4 * a * c;
               
                if (diskriminanta > 0 )
                {
                    Console.WriteLine("x1= {0}; x2 = {1}", ((-b + Math.Sqrt(diskriminanta)) / (2 *a)), ((-b - Math.Sqrt(diskriminanta)) / (2 * a)));  
                }
                else
                {
                    if (diskriminanta == 0)
                    {
                        Console.WriteLine("x1=x2={0}", (-b / (2.0 * c)));  
                    }
                    else 
                    {
                        Console.WriteLine("here are no real roots to the equation.");
                    }
                }
            }
            else
            {
                Console.WriteLine("Wrong Input! Please restart the program.");
            }
        }
    }
