﻿using System;
using System.Collections.Generic;
     
    class _17_CatchTheBits
    {
        static void Main()
        {
            byte n = byte.Parse(Console.ReadLine());
            short step = sbyte.Parse(Console.ReadLine());
            short count = 6;
            string result = null;
            List<int> numbers = new List<int>();
            for (int i = 1; i <= n; i++)
            {
                numbers.Add(int.Parse(Console.ReadLine()));
            }

            foreach (var number in numbers)
            {
                while (count>=0)
                {
                    result += Convert.ToString(GetBit(number,count));
                    count -= (step);
                }
                count = (byte)(7 + count + 1);
            }

            byte diff = (byte)(8 - (result.Length - ((result.Length) / 8)*8));
            if (diff<8)
            {
                result = result + new string('0', diff); 
            }
            
            
            for (int i = 0; i <= result.Length; i+=8)
            {
                int writeResult = Convert.ToInt32(result.Substring(0, 8),2);
                result = result.Remove(0, 8);
                Console.WriteLine(writeResult);
            }
               
        }       

        static byte GetBit(int numberInQuestion, short position)
        {
            int helpNumber;
            helpNumber = numberInQuestion >> position;
            return (byte)(helpNumber & 1);
        }
    }

