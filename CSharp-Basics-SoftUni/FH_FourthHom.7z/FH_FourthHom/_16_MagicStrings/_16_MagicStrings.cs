﻿using System;
using System.Collections.Generic;


class _16_MagicStrings
{
    // it's not alphabetical solution
    static void Main()
    {
        byte diff = byte.Parse(Console.ReadLine());
        bool existsMagicStr = false;
        string[] symbols = new string[] { null, "k", null, "s", "n", "p" };
        List<string> mirrorAnswers = new List<string>();
        
        if (diff <= 16)
        {
            for (byte i = 1; i <= 5; i++)
            {
                if (i == 2)
                {
                    continue;
                }

                for (byte j = 1; j <= 5; j++)
                {
                    if (j == 2)
                    {
                        continue;
                    }

                    for (byte l = 1; l <= 5; l++)
                    {
                        if (l == 2)
                        {
                            continue;
                        }

                        for (byte w = 1; w <= 5; w++)
                        {
                            if (w == 2)
                            {
                                continue;
                            }


                            short sum = (short)(i + l + j + w + diff);

                            for (byte s = 1; s <= 5; s++)
                            {
                                if (s == 2)
                                {
                                    continue;
                                }

                                for (byte n = 1; n <= 5; n++)
                                {
                                    if (n == 2)
                                    {
                                        continue;
                                    }

                                    for (byte k = 1; k <= 5; k++)
                                    {
                                        if (k == 2)
                                        {
                                            continue;
                                        }

                                        for (byte p = 1; p <= 5; p++)
                                        {
                                            if (p == 2)
                                            {
                                                continue;
                                            }


                                            if ((k + s + n + p) == sum)
                                            {
                                                string answer = symbols[i] + symbols[j] + symbols[l] + symbols[w] + symbols[s] + symbols[n] + symbols[k] + symbols[p];
                                                Console.WriteLine(answer);
                                                answer = symbols[s] + symbols[n] + symbols[k] + symbols[p] + symbols[i] + symbols[j] + symbols[l] + symbols[w];
                                                mirrorAnswers.Add(answer);                                                    
                                                //Console.WriteLine(answer);
                                                existsMagicStr = true;
                                            }


                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }

            
        }
        if (existsMagicStr == false)
        {
            Console.WriteLine("No");
        }
        else
        {
            foreach (var answer in mirrorAnswers)
            {
                Console.WriteLine(answer);
            }
        }
    }
}
    

