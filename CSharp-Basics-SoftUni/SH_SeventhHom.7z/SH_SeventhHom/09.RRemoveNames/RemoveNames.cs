﻿using System;
using System.Collections.Generic;
using System.Linq;

    class RemoveNames
    {
        static void Main()
        {
            //string strInitialInput = "Hristo Hristo Nakov Nakov Petya";
            string strInput = Console.ReadLine();
            //string strSecondInput = "Nakov Vanessa Maria";              
            string strSecondInput = Console.ReadLine();
            string[] arrOfNames = strInput.Split(' ');
            List<string> finalListOfNames = arrOfNames.ToList();
            string[] secondaryInputStrArray = strSecondInput.Split(' ');

            for (int i = 0; i < arrOfNames.Length; i++)
			{
			    foreach (var secName in secondaryInputStrArray)
                {
                    if (arrOfNames[i] == secName)
                    {
                        finalListOfNames.RemoveAll(item => item == secName);                        
                    }
                }
			}  
            for (int i = 0; i < finalListOfNames.Count; i++)
            {
                Console.Write(finalListOfNames[i] + " "); 
            }
            Console.WriteLine();
        }
    }

