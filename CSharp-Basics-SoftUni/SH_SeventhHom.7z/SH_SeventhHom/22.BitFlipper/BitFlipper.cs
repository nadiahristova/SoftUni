﻿using System;

    class BitFlipper
    {
        static void Main()
        {
            ulong input = ulong.Parse(Console.ReadLine());
            int indexOfEndBit = 62;

            while (indexOfEndBit >0)
            {
                indexOfEndBit--;
                ulong lastSegment = (input >> indexOfEndBit) & 7;

                if (lastSegment == 0 || lastSegment == 7)
                {
                    input = input ^ ((ulong)7 << indexOfEndBit);
                    indexOfEndBit -= 2;
                }

            }             
            
            Console.WriteLine(input);
        }
    }

