﻿using System;

    class FibonacciNumbers
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int answer;

            answer = FibonacciCreator(n);
            Console.WriteLine(answer);

        }

        static int FibonacciCreator(int nthNum)
        {
            int fibNum = 0;
            int fibHelp = 1;

            for (int i = 0; i <= nthNum; i++)
            {
                int fibHelpSecond = fibNum;
                fibNum = fibNum + fibHelp;
                fibHelp = fibHelpSecond;
            }

            return fibNum;
        }
    }

