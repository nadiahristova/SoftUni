﻿ //     <@ _ @> shantava zadacha

using System;
using System.Collections.Generic;
using System.Linq;

    class Point
    {
        public int X { get; set; }
        public int Y { get; set; }
    }

    class PerimeterAndAreaOfPolygon
    {
        static void Main()
        {
            Console.WriteLine("How many poinst do we need in order to compose the polygon?");
            int numOfPointsInPoly = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the coordinates of the points:");
            double perimeterOfPolygon;
            double areaOfPolygon;

            Polygon poly = new Polygon();
            poly.Points = new List<Point>();

            for (int i = 0; i < numOfPointsInPoly; i++)
            {
               string currPoint = Console.ReadLine();
               int[] pointCoordinateHolder = currPoint.Split(' ').Select(coo => int.Parse(coo)).ToArray();
               poly.Points.Add(new Point() { X = pointCoordinateHolder[0], Y = pointCoordinateHolder[1]}); 
            }

            perimeterOfPolygon = PerimeterOfGivenPolygon(poly.Points);
            areaOfPolygon = Math.Abs(AreaOfGivenPolygon(poly.Points));

            Console.WriteLine("perimeter = {0:f2}", perimeterOfPolygon);
            Console.WriteLine("area = {0:0.##}", areaOfPolygon);
        }

        static double PerimeterOfGivenPolygon(List<Point> Polygon)
        {
            double perimeter = 0;

            for (int i = 0; i < Polygon.Count; i++)
            {
                if (i == Polygon.Count - 1)
                {
                    perimeter = perimeter + DistanceBetweenPoints(Polygon[i], Polygon[0]);
                }
                else
                {
                    perimeter = perimeter + DistanceBetweenPoints(Polygon[i], Polygon[i + 1]);
                }
            }

            return perimeter;
        }

        static double AreaOfGivenPolygon(List<Point> Polygon)
        {
            double area = 0;

            for (int i = 0; i < Polygon.Count; i++)
            {
                if (i != Polygon.Count - 1)
                {
                    area = area + (Polygon[i].X * Polygon[i + 1].Y - Polygon[i].Y * Polygon[i + 1].X) / 2.0;
                }
                else
                {
                    area = area + (Polygon[i].X * Polygon[0].Y - Polygon[i].Y * Polygon[0].X) / 2.0;
                }
            }

            return area;
        }

        static double DistanceBetweenPoints(Point a, Point b)
        {
            double distance = Math.Sqrt(Math.Pow((b.X - a.X), 2) + Math.Pow((b.Y - a.Y), 2));

            return distance;
        }
    }

    class Polygon
    {
        public List<Point> Points { get; set; }
    }


