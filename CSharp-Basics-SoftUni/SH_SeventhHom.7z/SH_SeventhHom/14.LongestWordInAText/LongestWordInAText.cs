﻿using System;
using System.Linq;
//using System.Text.RegularExpressions;

    class LongestWordInAText
    {   
        static void Main()
        {
            string input = Console.ReadLine();
            var words = input.Split(new char[] { ' ', ',', '.', ':', }, StringSplitOptions.RemoveEmptyEntries);             
            string longestWord = String.Empty;

            foreach (var word in words)
            {
                if (word.Length > longestWord.Length)
                {
                    longestWord = word; 
                } 
            }

            Console.WriteLine(longestWord);
        }
        

        //static void Main()
        //{
        //    string input = "Welcome to the Software University.";
        //}

        //static string[] GetWords(string input)
        //{
        //   MatchCollection  matches = Re gex.Matches(input,@"\b[\w']*\b]");
        //   var words = from m in matches.Cast<Match>()
        //               where !string.IsNullOrEmpty(m.Value)
        //               select TrimSuffix(m.Value);

        //   return words.ToArray();                          
        //}
    }

