﻿using System;    
using System.Linq;
using System.Threading;  

    class CountingAWOrdInText
    {
        static void Main()
        {
            string input=@"The Software University (SoftUni) trains software engineers, gives them a profession and a job.
            Visit us at http://softuni.bg. Enjoy the SoftUnification at SoftUni.BG. Contact us.Email: INFO@SOFTUNI.BG. 
            Facebook: https://www.facebook.com/SoftwareUniversity. YouTube: http://www.youtube.com/SoftwareUniversity. 
            Google+: https://plus.google.com/+SoftuniBg/. Twitter: https://twitter.com/softunibg. GitHub: https://github.com/softuni";
            string soughtWord="SoftUni";
            int counter = 0;

            var words = input.Split(new char[]{' ','\'','.','?','!','-','/','(',')','@'}, StringSplitOptions.RemoveEmptyEntries);

            foreach (var word in words)
	        {
		         if (soughtWord.Equals(word, StringComparison.CurrentCultureIgnoreCase))
	            {
		           counter++;
	            }
	        }

            Console.WriteLine(counter);
        }
    }                                            
                                                       
