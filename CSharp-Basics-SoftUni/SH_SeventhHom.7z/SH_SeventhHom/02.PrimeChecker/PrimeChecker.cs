﻿using System;

    class PrimeChecker
    {
        static void Main()
        {
            long number = long.Parse(Console.ReadLine());

            Console.WriteLine(IsPrime(number));
        }

        static bool IsPrime(long number)
        {
            bool isPrime = true;
            double fullUpTo = Math.Sqrt(Math.Abs(number));
            int upTo = (fullUpTo != 0 ? (int)fullUpTo+1 : (int)fullUpTo);

            if (number >= -1 && number <= 1)
            {
                isPrime = false;
            }
            else
            {              
            for (int i = 2; i <= upTo; i++)
            {
                if (number % i == 0 && number != 2)
                {
                    isPrime = false;
                } 
            }
            }

            return isPrime;
        }
    }

