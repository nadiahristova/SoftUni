﻿using System;

    class MagicCarNumbs
    {
        static void Main()
        {
            int weightGiven = int.Parse(Console.ReadLine());
            int totalNum = 0;
            int[] weightOfChars = new int[] { 10, 20, 30, 50, 80, 110, 130, 160, 200, 240 };
            char[] corrLetters = new char[] { 'A', 'B', 'C', 'E', 'H', 'K', 'M', 'P', 'T', 'X' };
            weightGiven = weightGiven - 40;
            int currWeight;
            int countZeroK = 0;

            for (int a = 0; a < 10; a++)
            {
                for (int b = 0; b < 10; b++)
                {
                    for (int i = 0; i < weightOfChars.Length; i++)
                    {
                        for (int j = 0; j < weightOfChars.Length; j++)
                        {
                            for (int k = 0; k < 6; k++)
                            {
                                currWeight = digitWeight(k, a, b) + weightOfChars[i] + weightOfChars[j];
                                if (weightGiven == currWeight && a != b )
                                {
                                    if (k==0)
                                    {
                                        countZeroK++; 
                                    }
                                    totalNum++;
                                    string subStr = null;
                                    switch (k)
                                    {
                                        case 0: subStr = a.ToString() + a.ToString() + a.ToString() + a.ToString(); break;
                                        case 1: subStr = a.ToString() + b.ToString() + b.ToString() + b.ToString(); break;
                                        case 2: subStr = a.ToString() + a.ToString() + a.ToString() + b.ToString(); break;
                                        case 3: subStr = a.ToString() + a.ToString() + b.ToString() + b.ToString(); break;
                                        case 4: subStr = a.ToString() + b.ToString() + a.ToString() + b.ToString(); break;
                                        case 5: subStr = a.ToString() + b.ToString() + b.ToString() + a.ToString(); break;
                                        default: break;
                                    }
                                    //Console.Write("CA" + subStr + corrLetters[i] + corrLetters[j] + ", ");
                                }
                            }
                        }
                    }
                }  
            }

            if (countZeroK !=0)
            {
                totalNum = totalNum - (countZeroK - 2 * countZeroK / 16);
            }
            Console.WriteLine(totalNum);
        }

        static  int digitWeight(int caze, int a, int b)
        {
            int weight = 0;

            switch (caze)
            {
                case 0: weight = 4 * a; break;
                case 1: weight = a + 3 * b; break;
                case 2: weight = 3 * a + b; break;
                case 3: weight = 2 * a + 2 * b; break;
                case 4: weight = 2 * a + 2 * b; break;
                case 5: weight = 2 * a + 2 * b; break;                  
                default: break;
            }

            return weight;
        }
    }

