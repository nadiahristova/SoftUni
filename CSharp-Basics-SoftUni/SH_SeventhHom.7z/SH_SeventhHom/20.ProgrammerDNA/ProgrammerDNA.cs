﻿using System;

    class Program
    {
        static void Main()
        {
            int Rolls = int.Parse(Console.ReadLine());
            char iniChar = char.Parse(Console.ReadLine());
            char currChar = iniChar;
            int blocks = 0;
            int numOfRolls = Rolls;
            

            do
            {
                int numberOfDigits = 1;
                numOfRolls = Rolls - blocks * 7;
            if (numOfRolls<7)
	        {
                numOfRolls = Rolls % 7;
	        } else numOfRolls = 7;
            
            for (int i = 1; i <= numOfRolls; i++)
            {                   
                string str = DNAWeaver(i, (char)(currChar));
                Console.WriteLine(str);                 

                currChar = (char)(currChar + numberOfDigits);
                int diff = 'G' - currChar;
                if (diff < 0)
                {                       
                    currChar = (char)('A' - diff-1);
                }                  

                if (i < 4)
                {
                    numberOfDigits = 5 - 2 * (7 / 2 - i - 1);
                }
                else numberOfDigits = 7 + 2 * (7 / 2 - i);
                
            }
            blocks++;
            } while (blocks != Rolls / 7+1);
        }

        static string DNAWeaver (int currRoll, char begginerChar)
        {
            string roll = null;

            if (currRoll >= 1 && currRoll <=4)
            {
                roll = new string('.', 7 / 2 - currRoll + 1) + ABCDECT(begginerChar, currRoll) + new string('.', 7 / 2 - currRoll + 1);
            }
            else if (currRoll >= 5 && currRoll <=7)
            {
                roll = new string('.', -7 / 2 + currRoll - 1) + ABCDECT(begginerChar, currRoll) + new string('.', -7 / 2 + currRoll - 1); 
            }

            return roll;
        } 

        static string ABCDECT(char initialChar, int roll)
        {
            int numberOfDigits;
            if (roll<=4)
	        {
               numberOfDigits = 5 - 2 * (7 / 2 - roll);
            }
            else numberOfDigits = 9 + 2 * (7 / 2 - roll);

            string str = null;

            for (int i = 0; i < numberOfDigits; i++)
            {
                int isInRange = initialChar + i;
                if (isInRange > 71)
                {
                    isInRange = isInRange - 7; 
                }
                str += ((char)(isInRange)).ToString();
            }

            return str;
        }
     }
   

