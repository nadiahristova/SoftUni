﻿using System;

    class InsideTheBuilding
    {
        static void Main()
        {
            int x, y;            
            int scale = int.Parse(Console.ReadLine());
           

            for (int i = 1; i < 6; i++)
            {                   
                x = int.Parse(Console.ReadLine());
                y = int.Parse(Console.ReadLine());

                if (InsideArea1(x, y, scale) || InsideArea2(x, y, scale))
                {
                    Console.WriteLine("inside");
                }
                else Console.WriteLine("outside");
            }
        }

        static bool InsideArea1(int x, int y, int multifier)
        {
            if (x>=0 && x<=3*multifier && y<=multifier && y>=0)
            {
                return true;
            }

            return false;
        }

        static bool InsideArea2(int x, int y, int multifier)
        {
            if (x >= multifier && x <= 2*multifier && y <= 4*multifier && y >= multifier)
            {
                return true;
            }

            return false;
        }
    }

