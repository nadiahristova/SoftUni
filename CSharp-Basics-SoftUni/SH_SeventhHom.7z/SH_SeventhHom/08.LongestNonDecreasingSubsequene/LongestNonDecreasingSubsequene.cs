﻿using System;
using System.Collections.Generic;
using System.Linq;

class LongestNonDecreasingSubsequene
{
    static void Main()
    {
        string initialInput = Console.ReadLine().Trim();
        //string[] strInput = initialInput.Split(' ');
        //int[] input = new int[strInput.Length];          
        int[] input = initialInput.Split(' ').Select(s => int.Parse(s)).ToArray();
        int helpCounter = 0;
        int currentValurIntArr = input[0];
        int detCount = 1;

        //for (int i = 0; i < input.Length; i++)
        //{
        //    input[i] = int.Parse(strInput[i]);
        //}
        ////int[] input = new int[] { 1, 1, 1, 2, 2, 2 };

        List<List<int>> consecutiveListOfAnswers = new List<List<int>>();
        List<int[]> connectionHolder = new List<int[]>();
        List<int?> helpList = new List<int?>();
        int[][] inputIncreasingLayout = new int[input.Length][];

        //for (int i = 1; i < input.Length; i++)
        //{
        //    if (currentValurIntArr == input[i])
        //    {
        //        List<int> an = new List<int>();

        //    }
        //    currentValurIntArr = input[i];
        //}
        //do
        //{
        //  if (currentValurIntArr == input[helpCounter])
        //    {
        //      List<int> answer = new List<int>();
        //      answer.Add(currentValurIntArr);
        //      answer.Add(currentValurIntArr);
        //      detCount = detCount +2;
        //       for (int i = helpCounter+1; i < input.Length; i++)
        //        {
        //            if (input[i-1]==input[i])
        //            {
        //              answer.Add(input[i]);
        //              detCount++;
        //            }
        //        }
        //    helpCounter = detCount +helpCounter;
        //    } else helpCounter++;
        //    detCount = 0;
        //} while (helpCounter <= input.Length);

        List<int> ans = new List<int>();
        for (int i = 1; i < input.Length; i++)
        {
            List<int> blq = new List<int>();    
            if (input[i - 1] == input[i])
            {
                detCount++;
                ans.Add(input[i]);
                if (i == input.Length-1)
                {
                   ans.Add(input[i-1]);
                   blq = ans;
                   consecutiveListOfAnswers.Add(blq);
                }
            }
            else if (detCount > 1)
            {
                ans.Add(input[i - 1]);
                blq = ans;
                consecutiveListOfAnswers.Add(blq);
                ans.Clear();
            }
        }

        if (!(detCount + consecutiveListOfAnswers.Count - 1 == input.Length))
        {
            for (int i = 0; i < input.Length; i++)
            {
                int[] arr = { i, input[i] };
                connectionHolder.Add(arr);
                helpList.Add(input[i]);
            }

            for (int i = 0; i < input.Length; i++)
            {
                int indexOfMinEl = helpList.IndexOf(helpList.Min());
                inputIncreasingLayout[i] = connectionHolder[indexOfMinEl];
                helpList[indexOfMinEl] = null;
            }

            for (int i = 0; i < input.Length / 2 + 1; i++)
            {
                List<int> answer = new List<int>();
                answer.Add(inputIncreasingLayout[i][1]);
                int currentKey = inputIncreasingLayout[i][0];
                for (int j = i + 1; j <= input.Length - 1; j++)
                {
                    int lastValue = answer.Last();
                    if (currentKey <= inputIncreasingLayout[j][0] && lastValue != inputIncreasingLayout[j][1])
                    {
                        answer.Add(inputIncreasingLayout[j][1]);
                        currentKey = inputIncreasingLayout[j][0];
                    }
                    //if (lastValue == inputIncreasingLayout[j][1] && j>=helpCounter)
                    //{                 
                    //    List<int> blockAnswer = new List<int>();
                    //    blockAnswer.Add(lastValue);
                    //    blockAnswer.Add(lastValue);
                    //    for (int k = j+1; k < input.Length; k++)
                    //    {
                    //        if ( inputIncreasingLayout[k-1][1] ==  inputIncreasingLayout[k][1]  )
                    //        {
                    //            helpCounter++;
                    //            blockAnswer.Add(inputIncreasingLayout[k][1]);
                    //        }                             
                    //    }
                    //    blockListOfAnswers.Add(blockAnswer);                         
                    //}
                }
                consecutiveListOfAnswers.Add(answer);
            }
        }
        //int num = 0;
        int numCount = 0;
        List<int> theAnswer = new List<int>();

        //foreach (var list in blockListOfAnswers)
        //{
        //    num = list.Count + num;
        //    if (numCount < list.Count)
        //    {
        //        numCount = list.Count;
        //        theAnswer = list;
        //    }
        //}

        //if (numCount != input.Length)
        //{
        //numCount = 0;
        //consecutiveListOfAnswers.Reverse();
        foreach (var item in consecutiveListOfAnswers)
        {
            if (numCount < item.Count)
            {
                numCount = item.Count;
                theAnswer = item;
            }
        } 
            //}               

            foreach (var list in theAnswer)
            {
                Console.Write(list + " ");
            }
            Console.WriteLine();
        }
    }

