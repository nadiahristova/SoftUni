﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text.RegularExpressions;   

    class ExtractURLsFromText
    {
        static void Main()
        {
            string input = "The site nakov.com can be access from http://nakov.com or www.nakov.com. It has subdomains like mail.nakov.com and svetlin.nakov.com. Please check http://blog.nakov.com for more information.";
            List<Uri> urlList = new List<Uri>();
            Uri currUri = null;

            var wordsURLorNot = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            Regex urlsWithWWW = new Regex(@"(?:https?://|www.)\S+\b", RegexOptions.Compiled | RegexOptions.IgnoreCase);                

            foreach (var word in wordsURLorNot)
            {
                Match match = urlsWithWWW.Match(word);

                if (Uri.TryCreate(match.Value, UriKind.RelativeOrAbsolute, out currUri) && match != Match.Empty)
                {
                    urlList.Add(currUri);
                }                
            }


            foreach (var url in urlList)
            {
                Console.WriteLine(url);
            }


            // Longer Version:

            //string input = "The site nakov.com can be access from http://nakov.com or www.nakov.com. It has subdomains like mail.nakov.com and svetlin.nakov.com. Please check http://blog.nakov.com for more information.";
            //List<Uri> urlList = new List<Uri>();
            //Uri currUri = null;
           
            //var wordsURLorNot = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            //Regex urlsWithWWW = new Regex(@"(/|www.)\S+\b", RegexOptions.Compiled | RegexOptions.IgnoreCase); //With this Regex i'll find the matches for only the urls with the format www.something.domain               

            //foreach (var word in wordsURLorNot)
            //{
            //    if (Uri.TryCreate(word, UriKind.Absolute, out currUri))
            //    {
            //        urlList.Add(currUri);
            //    }
            //    else 
            //    {
            //        Match match = urlsWithWWW.Match(word);
            //        if (Uri.TryCreate(match.Value, UriKind.Relative, out currUri) && match != Match.Empty)
            //        {
            //            urlList.Add(currUri); 
            //        }
            //    }
            //}
                    

            //foreach (var url in urlList)
            //{
            //    Console.WriteLine(url);                                
            //}
        }
    }

