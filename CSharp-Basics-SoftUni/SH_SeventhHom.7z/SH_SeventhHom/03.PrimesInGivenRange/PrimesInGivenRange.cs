﻿using System;
using System.Collections.Generic;
using System.Linq;


    class PrimesInGivenRange
    {
        static void Main()
        {
            int start = int.Parse(Console.ReadLine());
            int end = int.Parse(Console.ReadLine());
            List<int> answer = new List<int>();

            answer = AllPrimesInGivenRange(start, end);

            if (answer.Count == 0)
            {
                Console.WriteLine("There are no prime numbers");
            }
            else
            {
                foreach (var num in answer)
                {
                    if (num == answer.Last())
                    {
                        Console.Write(num);
                        Console.WriteLine();
                    } else Console.Write(num + ", ");  
                }
            }
        }

        static List<int> AllPrimesInGivenRange(int start, int end)
        {
            List<int> output = new List<int>();              

            for (int num = start; num <= end; num++)
            {
                bool isPrime = IsPrime(num);
                if (isPrime == true)
	            {
                    output.Add(num);
	            }
            }

            return output;
        }

        static bool IsPrime(int number)
        {
            int upTo;
            bool isPrime = true;             
            bool isInteger = int.TryParse(Math.Sqrt(number).ToString(), out upTo);
            upTo = (int)Math.Sqrt(Math.Abs(number));
            //int upTo = (Math.Sqrt(number) % 1 ==0 ? (int)Math.Sqrt(number) : (int)Math.Sqrt(number) + 1);
            if (!isInteger)
            {
                upTo++; 
            }

            if (number>=-1 && number<=1)
	        {
		       return false;
	        } else
            {
               for (int i = 2; i <= upTo; i++)
                {
                    if (number % i == 0 && number != 2)
                    {
                       return false;  
                    }
                }
            }

            return isPrime;
        }

    }

