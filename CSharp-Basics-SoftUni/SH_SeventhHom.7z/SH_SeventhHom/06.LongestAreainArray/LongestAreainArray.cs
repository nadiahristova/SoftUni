﻿using System;

    class LongestAreainArray
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());            
            string[] strArray = new string[n];

            for (int i = 0; i < n; i++)
            {
                strArray[i] = Console.ReadLine();
            }

            int currentMaxCount = 0;            
            string currentMaxStr = null;
            int p = 0;

            do
            {
                int currentCount = 0;
                string currentStr = strArray[p];
                               
                for (int i=p; i <= n-1 && (currentStr == strArray[i]); i++)
                {
                    currentCount++;
                    p++; 
                }
              
                if (currentCount > currentMaxCount)
                {
                    currentMaxCount = currentCount;
                    currentMaxStr = strArray[p - 1];
                }              
            } while (p<n);

            Console.WriteLine();
            Console.WriteLine(currentMaxCount); 
            for (int i = 0; i < currentMaxCount; i++)
            {
                Console.WriteLine(currentMaxStr); 
            }
        }
    }

