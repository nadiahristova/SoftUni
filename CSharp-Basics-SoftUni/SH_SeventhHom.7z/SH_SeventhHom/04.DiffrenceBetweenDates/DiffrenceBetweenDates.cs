﻿using System;
using System.Globalization;

    class DiffrenceBetweenDates
    {
        static void Main()
        {              
            DateTime FirstDate = DateTime.ParseExact(Console.ReadLine(), "dd.MM.yyyy", null);
            DateTime SecondDate = DateTime.ParseExact(Console.ReadLine(), "dd.MM.yyyy", CultureInfo.InvariantCulture);

            //TimeSpan timeBetweenDays = SecondDate - FirstDate;
            TimeSpan timeBetweenDays = SecondDate.Subtract(FirstDate);

            Console.WriteLine(Math.Abs(timeBetweenDays.Days));
        }
    }

