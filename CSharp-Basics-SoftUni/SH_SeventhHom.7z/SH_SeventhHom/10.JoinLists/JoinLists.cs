﻿using System;
using System.Collections.Generic;
using System.Linq;

    class JoinLists
    {
        static void Main()
        {
            string firstInput = Console.ReadLine().Trim();
            string secondInput = Console.ReadLine().Trim();
            List<int> firstList = firstInput.Split(' ').Select(s => int.Parse(s)).ToList();
            List<int> secondList = secondInput.Split(' ').Select(s => int.Parse(s)).ToList();
            //firstList.AddRange(secondList); - second variant to merge lists
            var answer = firstList.Concat(secondList).ToList();
            answer = answer.Distinct().ToList();
            answer = answer.OrderBy(v => v).ToList();
            //answer.Sort(); - secont variant to sort numbers without the need of Linq  
            //IEnumerable<int> union = firstList.Union(secondList); - merges 2 lists and remove the repetitive numbers
            foreach (var num in answer)
            {
                Console.Write(num + " "); 
            }

            Console.WriteLine();
        }
    }

                                               