﻿using System;
using System.Collections.Generic;
using System.Linq;

    class CountOfNames
    {
        static void Main()
        {
            string initialInput = Console.ReadLine();
            int count;
            List<string> strList = initialInput.Split().ToList();
            List<string> listOfUniqueSortedStr = strList.Distinct().OrderBy(str => str).ToList();
            for (int i = 0; i < listOfUniqueSortedStr.Count; i++)
            {
                count = 0;
                foreach (var str in strList)
                {
                    if (listOfUniqueSortedStr[i] == str)
                    {
                        count++;  
                    }
                }
                Console.WriteLine("{0} -> {1}", listOfUniqueSortedStr[i], count);
            }
        }
    }

