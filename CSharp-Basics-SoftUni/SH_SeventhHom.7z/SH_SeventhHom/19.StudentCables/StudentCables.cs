﻿using System;
using System.Threading;
using System.Globalization;

    class StudentCables
    {
        const int StudentCable = 504;
        const string m = "meters";         
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            int numOfCablesWithDiffSizes = int.Parse(Console.ReadLine());
            int allInAllLength = 0;
            int countOfConnections = 0;
            int countOfStudentCables = 0;
            double remainer = 0;                             
                         
            for (int i = 0; i < numOfCablesWithDiffSizes; i++)
            {
                int lengthOfCable = int.Parse(Console.ReadLine());
                string unit = Console.ReadLine();

                if (unit == m)
                {
                    lengthOfCable = lengthOfCable * 100;
                }
               

                if (lengthOfCable >= 20)
                {
                    allInAllLength = allInAllLength + lengthOfCable;
                    countOfConnections++;
                }                  
            }

            allInAllLength = allInAllLength - (countOfConnections -1 )* 3;
            countOfStudentCables = allInAllLength / StudentCable;
            remainer = allInAllLength % StudentCable;   

            Console.WriteLine(countOfStudentCables);
            Console.WriteLine(remainer);
        }
    }

