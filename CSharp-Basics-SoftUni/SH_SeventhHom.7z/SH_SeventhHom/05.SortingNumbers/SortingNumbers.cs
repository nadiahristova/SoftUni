﻿using System;
using System.Linq;

    class SortingNumbers
    {
        static void Main()
        {
            int totalNumbers = int.Parse(Console.ReadLine());

            int[] listOfNumbers = new int[totalNumbers];

            for (int i = 0; i < listOfNumbers.Length; i++)
            {
                listOfNumbers[i] = int.Parse(Console.ReadLine());
            }

            Array.Sort(listOfNumbers);               

            foreach (var num in listOfNumbers)
            {
                Console.WriteLine(num); 
            }
        }
    }

