﻿using System;

    class MatrixOfPalindromes
    {
        static void Main()
        {
            int roll = int.Parse(Console.ReadLine());
            int coll = int.Parse(Console.ReadLine());
            string[,] MatrixOfPoindromes = new string[coll, roll];

            for (int i = 0; i < roll; i++)
            {
                for (int j = 0; j < coll; j++)
                {
                    MatrixOfPoindromes[j, i] = "" + (char)('a' + i) + (char)('a' + j + i) + (char)('a' + i);
                } 
            }

            for (int i = 0; i < roll; i++)
            {
                for (int j = 0; j < coll; j++)
                {
                    Console.Write(MatrixOfPoindromes[j, i] + " ");
                }
                Console.WriteLine();
            } 
        }         
    }

