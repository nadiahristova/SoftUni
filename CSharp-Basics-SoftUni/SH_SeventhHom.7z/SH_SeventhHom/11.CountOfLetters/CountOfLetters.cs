﻿using System;
using System.Collections.Generic;
using System.Linq;

    class CountOfLetters
    {
        static void Main()
        {
            string input = Console.ReadLine().Trim();
            List<char> chInput = input.Split(' ').Select(ch => char.Parse(ch)).ToList();
            List<char> listWithNoDuplicates = new List<char>();
            listWithNoDuplicates = chInput.Distinct().OrderBy(ch => ch).ToList();
            int duplicateCounter;

            for (int i = 0; i < listWithNoDuplicates.Count; i++)
            {
                duplicateCounter = 0;

                foreach (var cha in chInput)
                {
                    if (cha == listWithNoDuplicates[i] )
                    {
                        duplicateCounter++; 
                    }  
                }
                Console.WriteLine("{0} -> {1}", listWithNoDuplicates[i],duplicateCounter);
            }
        }
    }

