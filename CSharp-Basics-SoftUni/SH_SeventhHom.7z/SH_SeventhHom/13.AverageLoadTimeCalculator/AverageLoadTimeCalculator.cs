﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Threading; 

    class AverageLoadTimeCalculator
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            Console.WriteLine("To terminate further data uploading press the ESC key on the new line.");          
            Dictionary<Uri, float> output = new Dictionary<Uri, float>();  

            do
            {
                string input = Console.ReadLine();
                string[] stirredInput = input.Split(' ').ToArray();
                DateTime time = new DateTime();
                Uri uri = new Uri("http://kolibka.net");
                Uri getUri = null; 
                float secs = 0;
                float getSecs = 0;
                bool urlIsPresent = false;

                for (int i = 0; i < stirredInput.Length; i++)
			    {
			       if (!DateTime.TryParse(stirredInput[i], out time) )
	                { 	                      
                        if (Uri.TryCreate(stirredInput[i],UriKind.Absolute,out uri))
	                    {
                           getUri = uri;
		                   foreach (var siteInfo in output)
	                        {
		                        if (siteInfo.Key == uri)
	                            {
		                          urlIsPresent= true;
	                            } 
	                        }
                        }                         
	                }

                   if (float.TryParse(stirredInput[i], out secs))
                   {
                       getSecs = secs;
                   } 
			    }

                 if (!urlIsPresent)
	                {
                        output.Add(getUri, 0);
	                }
                    output[getUri] = output[getUri] + getSecs;                 
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape);

            foreach (var item in output)
            {
                Console.WriteLine("{0} -> {1}", item.Key, item.Value); 
            }
        }         
    }

