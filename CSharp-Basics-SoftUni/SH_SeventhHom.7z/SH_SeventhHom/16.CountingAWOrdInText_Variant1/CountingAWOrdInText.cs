﻿using System;
using System.Linq;

    class CountingAWOrdInText_Variant1
    {
        static void Main()
        {
            //This program is variation of the given problem. It doesn't only find how many times a given word occurs in a text. It also finds  
            //the number of occurs of the word(as sequence of letters) in each word of the initial text.
            string input = "Hidden networks say “Hi” only to Hitachi devices. Hi, said Matuhi. HI!";
            string findAWord = "hi";
            var words = input.Split(new char[] { ' ', '.', ',', '!', '-', '?' }, StringSplitOptions.RemoveEmptyEntries);            

            Console.WriteLine(Counter(words,findAWord));
        }

        static int Counter(string[] text,string wordInQuestion)
        {
            int count = 0;              

            foreach (var word in text)
            {
                string currWord = word.ToLower();
                while (currWord.Contains(wordInQuestion.ToLower()))
                {
                    count++;
                    currWord = ReturnStringWithoutOneWordInQuestion(currWord, wordInQuestion);
                } 
            }

            return count;
        }

        static string ReturnStringWithoutOneWordInQuestion(string word, string wordInQuestion)
        {
            int index = word.LastIndexOf(wordInQuestion.ToLower());
            word = word.Remove(index, wordInQuestion.Length);

            return word;
        }
    }

