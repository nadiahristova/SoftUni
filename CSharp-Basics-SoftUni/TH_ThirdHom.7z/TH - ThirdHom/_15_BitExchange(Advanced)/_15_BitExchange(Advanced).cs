﻿using System;

    class Program
    {
        static void Main()
        {
            uint numHelp,mask;
            byte bit1, bit2;
            Console.Write("Please type in the number: ");
            uint num = uint.Parse(Console.ReadLine());
            Console.Write("p: ");
            byte p = byte.Parse(Console.ReadLine());
            Console.Write("q: ");
            byte q = byte.Parse(Console.ReadLine());
            Console.Write("Please type in the step: ");
            byte k = byte.Parse(Console.ReadLine());
            if (((p + k - 1) >= 32) || ((q + k - 1) >= 32)||(p<0)||(q<0))
            {
                Console.WriteLine("Out of range.");
            }
            else 
            {
                if ((q > p) & ((p + k - 1 >= q)) || ((q < p) & ((q + k - 1 >= p)) || (q == p)))
                {
                    Console.WriteLine("Overlapping");
                }
                else 
                {
                    for (byte i = 0; i < k; i++)
                    {
                        numHelp = num >> (p + i);
                        bit1 = (byte)(numHelp & 1);
                        numHelp = num >> (q + i);
                        bit2 = (byte)(numHelp & 1);

                        if (bit1!=bit2)
                        {
                            if (bit1 == 1)
                            {
                                mask = (uint)(~(1 << (p + i)));
                                num = num & mask;
                                mask = (uint)(1 << (q + i));
                                num = num | mask;
                            }
                            else
                            {
                                mask = (uint)(~(1 << (q + i)));
                                num = num & mask;
                                mask = (uint)(1 << (p + i));
                                num = num | mask;
                            }
                        }
                    }
                    Console.WriteLine(num);
                }                 
            }

        }
    }
