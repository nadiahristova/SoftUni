﻿using System;


    class _12_ExtractBitFromInteger
    {
        static void Main()
        {
            int newNumber;
            Console.Write("Please type in a number: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Please selec the bit index: ");
            byte p = byte.Parse(Console.ReadLine());
            newNumber = n >> p;
            Console.WriteLine(newNumber & 1);   
        }
    }

