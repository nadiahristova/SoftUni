﻿using System;



    class _14_ModifyABitAtGivenPosition
    {
        static void Main()
        {
            int numHelp, mask;
            byte digit;
            Console.Write("Please type in a number: ");
            int num = Int16.Parse(Console.ReadLine());
            Console.Write("Please type in a value 0 or 1: ");
            byte v = byte.Parse(Console.ReadLine());
            Console.Write("Please type in the position where the transformation will occur: ");
            byte p = byte.Parse(Console.ReadLine());
            numHelp = num >> p;
            digit =(byte) (numHelp & 1);
            if (digit == v)
            {
                Console.WriteLine("Nqmame promqna v chisloto. To e {0}", num);
            }
            else
            {
                if (v == 0)
                {
                    mask = ~(1 << p);
                    numHelp = num & mask;
                    Console.WriteLine(numHelp);
                }
                else 
                {
                    mask = (1 << p);
                    numHelp = num | mask;
                    Console.WriteLine(numHelp);
                }
            }            

        }
    }

