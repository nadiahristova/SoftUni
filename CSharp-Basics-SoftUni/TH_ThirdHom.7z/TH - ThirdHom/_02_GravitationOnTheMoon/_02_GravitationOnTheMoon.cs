﻿using System;


    class _02_GravitationOnTheMoon
    {
        static void Main()
        {
            Console.Write("Please type in the weight of a persone[kg]: ");
            double weightEarth = double.Parse(Console.ReadLine());
            double weightMoon = weightEarth * 17.0 / 100;
            Console.WriteLine("The weight of the man on the moon would be: {0}",weightMoon);
        }
    }

