﻿using System;



    class Program
    {
        static void Main()
        {
            float a, b, h;
            Console.Write("a= ");
            a = float.Parse(Console.ReadLine());
            Console.Write("b= ");
            b = float.Parse(Console.ReadLine());
            Console.Write("h= ");
            h = float.Parse(Console.ReadLine());
            if (a > b)
            {
                a = a - b;
                b = b + a;
                a = b - a;
            }
            double area = a * h + ((b - a) * h )/ 2.0;
            Console.WriteLine(area);
        }
    }

