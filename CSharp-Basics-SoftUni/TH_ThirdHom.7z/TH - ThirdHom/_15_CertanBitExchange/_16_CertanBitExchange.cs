﻿using System;



    class _15_CertanBitExchange
    {
        static void Main()
        {
            uint numHelp, mask;
            byte rightBit, leftBit;
            Console.Write("Please type in a number that is going to be modified: ");
            uint num = uint.Parse(Console.ReadLine());
            for (byte i = 3; i <= 5; i++)
			{
                numHelp = num >> i;
                rightBit = (byte)(numHelp & 1);
                numHelp = num >> (21 + i);
                leftBit = (byte)(numHelp & 1);
                
                if (leftBit != rightBit)
                {
                    if (rightBit == 1)
                    {
                        mask = (uint)~((1) << i);
                        num = num & mask;
                        mask = (uint)(1 << (21 + i));
                        num = num | mask;
                        //Console.WriteLine(Convert.ToString(num,2));
                    }
                    else 
                    {
                        mask = (uint)~((1) << (i + 21));
                        num = num & mask;
                        mask = (uint)(1 << (i));
                        num = num | mask;
                        //Console.WriteLine(Convert.ToString(num, 2));
                    }                     
                }
               // Console.WriteLine(Convert.ToString(num, 2));
                  			 
			}
            Console.WriteLine(num);

        }
    }

