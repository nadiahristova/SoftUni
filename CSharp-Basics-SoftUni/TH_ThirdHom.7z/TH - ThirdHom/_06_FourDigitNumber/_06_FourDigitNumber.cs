﻿using System;



    class _06_FourDigitNumber
    {
        static void Main()
        {
            int a1, a2, a3, a4, numUpdated;
            Console.Write("Please type in a four digit whole number: ");
            int num = int.Parse(Console.ReadLine());
            a1 = num / 1000;
            a2 = (num / 100) % 10;
            a3 = (num / 10) % 10;
            a4 = num  % 10;
            int sum = a1 + a2 + a3 + a4;
            Console.WriteLine(sum);
            numUpdated = a4 * 1000 + a3 * 100 + a2 * 10 + a1;
            Console.WriteLine(numUpdated);
            numUpdated = a4 * 1000 + a1 * 100 + a2 * 10 + a3;
            Console.WriteLine(numUpdated);
            numUpdated = a1 * 1000 + a3 * 100 + a2 * 10 + a4;
            Console.WriteLine(numUpdated);                
        }
    }

