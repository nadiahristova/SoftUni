﻿using System;
      
    class Program
    {
        static void Main()
        {
            Console.Write("IS the year leap or normal: ");
            string year = Console.ReadLine();
            Console.Write("Please insert the number of holidays: ");
            ushort  p = ushort.Parse(Console.ReadLine());
            Console.Write("Please insert the number of hometown visits: ");
            byte h = byte.Parse(Console.ReadLine());
            byte numberOfPlays =(byte)(2*p/3.0+h+3*(48-h)/4.0);
            if (year == "leap")
	            {
                    numberOfPlays = Convert.ToByte(numberOfPlays * 15 / 100+numberOfPlays);
	            }
            Console.WriteLine(numberOfPlays);
        }
    }

