﻿using System;


    class _04_Rectangles
    {
        static void Main()
        {
            Console.Write("Width: ");
            float width = float.Parse(Console.ReadLine());
            Console.Write("Height: ");
            float height = float.Parse(Console.ReadLine());
            Console.WriteLine("Perimeter of the rectangular is: {0}, The Area of the rectangular is: {1} ", width*2+height*2, width*height);

        }
    }

