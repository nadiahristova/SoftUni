﻿using System;
namespace _01_OddOrNot
{
    class _01_OddOrNot
    {
        static void Main()
        {
            bool bo = false;
            int n = int.Parse(Console.ReadLine());
            if (n % 2 == 0)
            {
                bo = false;
                Console.WriteLine(bo);
            }
            else
            {
                bo = true;
                Console.WriteLine(bo);
            }
        }
    }
}
