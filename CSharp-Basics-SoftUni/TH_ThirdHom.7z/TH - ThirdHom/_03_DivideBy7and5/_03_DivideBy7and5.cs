﻿using System;



    class _03_DivideBy7and5
    {
        static void Main()
        {
            Console.Write("Please type in a number: ");
            int num = int.Parse(Console.ReadLine());
            bool bo = (num % 5 == 0) && (num % 7 == 0);
            Console.WriteLine(bo);  
        }
    }

