﻿using System;



    class Program
    {
        static void Main()
        {
            bool isPrime = true;
            Console.Write("Type in a number: ");
            byte num = byte.Parse(Console.ReadLine());
            for (int i = 2; i <= num-1; i++)
            {
                if (num%i==0)
                {
                  isPrime=false;  
                }
            }
            Console.WriteLine(isPrime);
        }
    }

