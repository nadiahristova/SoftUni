﻿using System;



    class _07_PointInACircle
    {
        static void Main()
        {
            Console.Write("x = ");
            float x = float.Parse(Console.ReadLine());
            Console.Write("y = ");
            float y = float.Parse(Console.ReadLine());
            bool bo = (Math.Pow(x,2) +Math.Pow(y,2)) <= 4;
            Console.WriteLine(bo);
        }   

    }

