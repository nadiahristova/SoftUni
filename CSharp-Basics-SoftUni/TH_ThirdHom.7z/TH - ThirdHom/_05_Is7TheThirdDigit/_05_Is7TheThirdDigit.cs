﻿using System;



    class Program
    {
        static void Main()
        {
            Console.Write("Please type in one number: ");
            int num = int.Parse(Console.ReadLine());
            bool bo = ((num / 100) % 10) == 7;
            Console.WriteLine(bo);
        }
    }

