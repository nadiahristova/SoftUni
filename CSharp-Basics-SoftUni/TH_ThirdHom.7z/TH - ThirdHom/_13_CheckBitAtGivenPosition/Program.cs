﻿using System;
                

    class Program
    {
        static void Main()
        {
            int numHelp;
            Console.Write("Vyvedete chislo: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Vyvedete poziciq: ");
            byte p = byte.Parse(Console.ReadLine());
            bool bo=false;
            numHelp = n >> p;
            if ((numHelp & 1) == 1)
            {
                bo = true;
            }
            Console.WriteLine(bo);

        }
    }

