﻿using System; 

    class _19_TheExplorer
    {
        static void Main()
        {
            string dCherti, sreda;            
            byte counter;
            Console.Write("Please enter the height of the diamond: ");
            byte n = byte.Parse(Console.ReadLine());
            dCherti = new string('_',n/2);
            Console.WriteLine(dCherti+"*"+dCherti);
            counter = (byte)(n/2);
            for (byte i = 2; i < n; i++)
            {
                if (i<=(n/2+1))
                {
                    counter = (byte)(counter - 1);
                    dCherti = new string('_', counter);
                    sreda = new string('_', n-2-2*counter);
                    Console.WriteLine(dCherti+"*"+sreda+"*"+dCherti);
                }
                else
                {
                    counter = (byte)(counter + 1);
                    dCherti = new string('_', counter);
                    sreda = new string('_', n - 2 - 2 * counter);
                    Console.WriteLine(dCherti+ "*"+ sreda+ "*"+ dCherti);
                }
            }
            dCherti = new string('_', n / 2);
            Console.WriteLine(dCherti+ "*"+ dCherti);
        }
    }

