﻿using System;    

    class _18_OddOrEvenSum
    {
        static void Main()
        {
            short oddSum, evenSum, num;
            oddSum = evenSum = 0;
            Console.Write("Please insert the number of numbers: ");
            ushort n = ushort.Parse(Console.ReadLine());
            for (byte i = 2; i <= 2*n+1; i++)
            {
                Console.Write("Molq vyvedete {0}-toto chislo: ", i + 1);
                num = short.Parse(Console.ReadLine());
                if (i % 2 != 0)
                {
                    oddSum = (short)(oddSum + num);
                }
                else
                {
                    evenSum = (short)(evenSum + num);
                }                
            }
            if (oddSum == evenSum)
            {
                Console.WriteLine("Yes, sum = {0}.", oddSum);
            }
            else 
            {
                Console.WriteLine("No, diff= {0}.",Math.Abs(oddSum-evenSum));
            }
        }
    }
