﻿using System;
                      
    class _21_BitSifting
    {
        static void Main()
        {
            long numberToSieve, numHelp;
            byte numberOfSieves, trueBitCounter;
            bool bo = false; 
            Console.Write("Please type in a number( 64-bit ) to sieve: ");
            numberToSieve = long.Parse(Console.ReadLine());
            Console.Write("Please type in the number of sieves: ");
            numberOfSieves = byte.Parse(Console.ReadLine());
            long[] sieves = new long[numberOfSieves];
            for (int i = 0; i < numberOfSieves; i++)
            {
                Console.Write("Please type in the {0} sieve: ",i+1);
                sieves[i] = Convert.ToInt64(Console.ReadLine());
            }
            trueBitCounter = 0;
            for (byte i = 0; i < 64; i++)
            {
                if (numberOfSieves==0)
                {
                    numHelp = numberToSieve >> i;
                    numHelp = numHelp & 1;
                    if (numHelp==1)
                    {
                        trueBitCounter =(byte)(trueBitCounter + 1); 
                    }
                }
                else
                {
                    numHelp = numberToSieve >> i;
                    numHelp = numHelp & 1;
                    if (numHelp == 1)
                    {
                        for (byte j = 0; j < numberOfSieves; j++)
                        {
                            numHelp = sieves[j] >> i;
                            numHelp = numHelp & 1;
                            if (numHelp == 1)
                            {
                                bo = false;
                                break;
                            }
                            else
                            {
                                bo = true;
                            }
                        }
                        if (bo)
                        {
                            trueBitCounter = (byte)(trueBitCounter + 1);
                        }
                    }
                }
               
            }
            Console.WriteLine(trueBitCounter);
        }
    }

