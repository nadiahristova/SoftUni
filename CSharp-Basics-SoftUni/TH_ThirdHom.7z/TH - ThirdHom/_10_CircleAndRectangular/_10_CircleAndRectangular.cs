﻿using System;


    class _10_CircleAndRectangular
    {
        static void Main()
        {
            Console.Write("x = ");
            float x = float.Parse(Console.ReadLine());
            Console.Write("y = ");
            float y = float.Parse(Console.ReadLine());
            bool bo = (Math.Pow(x-1, 2) + Math.Pow(y-1, 2)) <= 1.5*1.5;
            if (y<=1)
            {
                bo = false;  
            }
            Console.WriteLine(bo);
        }
    }

