﻿using System;


    class _20_BitsUP
    {
        static void Main()
        {
            byte n, singleNumber, step, indexBit, mask, numHelp; 
            Console.Write("Please insert the number of numbers: ");
            n = byte.Parse(Console.ReadLine());
            Console.Write("Please type in the magnitute of the step: ");
            step = byte.Parse(Console.ReadLine());
            byte[] numbers=new byte[n];
            for (byte i = 0; i < n; i++)
            {
                Console.Write("{0}-th number is: ",i);
                singleNumber = byte.Parse(Console.ReadLine());
                numbers[i] = singleNumber;   
            }              
            indexBit = 1;
            byte j = 0;
            numHelp = 1;
           do
            {
                mask = (byte)(1 << (7 - indexBit));
                numbers[j] = (byte)(numbers[j] | mask);
                indexBit = (byte)(indexBit + step);
                numHelp = (byte)(numHelp + step); 
                if (indexBit>8)
                {
                    j = (byte)(numHelp / 8);
                    indexBit = (byte)(numHelp % 8);

                }                   
            } while (numHelp<=(8*n));
            for (int i = 0; i < n; i++)
            {
                Console.Write(numbers[i]+" ");
            }
        }
    }

