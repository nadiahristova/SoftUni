﻿using System;



    class _11_ExtractBitNo3
    {
        static void Main()
        {
            Console.Write("Please type in  a number: ");
            int num = int.Parse(Console.ReadLine());
            int help;
            Console.WriteLine(Convert.ToString(num,2));
            help = num >> 3;
            int look = help & 1;
            Console.WriteLine(look);
        }
    }

