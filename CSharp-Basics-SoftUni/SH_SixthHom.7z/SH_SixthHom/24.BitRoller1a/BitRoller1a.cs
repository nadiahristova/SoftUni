﻿using System;

class BitRoller_1
{
    const int size = 19;
    static void Main()
    {
        uint inputNumber = uint.Parse(Console.ReadLine());
        int posOfStationaryBit = int.Parse(Console.ReadLine());
        int rolls = int.Parse(Console.ReadLine());
        string helpIndex;
        int index = 0;
        int answer = 0;

        posOfStationaryBit = 19 - 1 - posOfStationaryBit; 
        string strVarOfInputNum = Convert.ToString(inputNumber, 2).PadLeft(19, '0');
        string[] result = new string[19];
        foreach (var item in strVarOfInputNum)
        {
            result[index] = item.ToString();
            index++;
        }

        for (int i = 0; i < rolls; i++)
        {
            helpIndex = null;
            string[] mediumResult = new string[19];
            for (int j = 18; j >= 0; j--)
            {
                if (j==posOfStationaryBit)
                {
                    mediumResult[j] = result[j];
                }
                else
                {
                    int newPosition = (j + 1) % 19;
                    if (newPosition == posOfStationaryBit)
                    {
                        newPosition = (newPosition + 1) % 19;
                    }
                    mediumResult[newPosition] = result[j];
                }              
            }
            result = mediumResult;
        }
        helpIndex = null;
        foreach (var strDigit in result)
        {
            helpIndex = helpIndex + strDigit;
        }

        answer = Convert.ToInt32(helpIndex, 2);
        Console.WriteLine(answer);
    }

}
