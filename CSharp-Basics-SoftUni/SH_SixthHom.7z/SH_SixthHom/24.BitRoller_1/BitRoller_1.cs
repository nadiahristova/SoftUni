﻿using System;

    class BitRoller_1 
    {
        const int size = 19;
        static void Main()
        {
            uint inputNumber = uint.Parse(Console.ReadLine());
            int posOfStationaryBit = int.Parse(Console.ReadLine());
            int rolls = int.Parse(Console.ReadLine());
            string helpIndex;
            int index = 0;
            int answer = 0;

            string strVarOfInputNum = Convert.ToString(inputNumber, 2).PadLeft(19, '0');            
            string[] result = new string[19];
            foreach (var item in strVarOfInputNum)
            {
               result[index] = item.ToString();
               index++; 
            }

            for (int i = 0; i < rolls; i++)
            {
                helpIndex = null;
                string[] mediumResult = new string[19];
                for (int j = 18; j >= 0; j--)
                {
                    if (j == 18)
                    {
                        mediumResult[0] = result[18];
                    }
                    else mediumResult[18-j] = result[17 - j];                                          
                }
                
                if (posOfStationaryBit==0)
	            {
                    helpIndex = mediumResult[18];
                    mediumResult[18] = mediumResult[0];
                    mediumResult[0] = helpIndex;
	            }
                else
                {
                    helpIndex = mediumResult[19 - posOfStationaryBit];
                    mediumResult[19 - posOfStationaryBit] = mediumResult[19 - posOfStationaryBit - 1];
                    mediumResult[19 - posOfStationaryBit - 1] = helpIndex;
                }
                result = mediumResult; 
            }
            helpIndex = null;
            foreach (var strDigit in result)
            {
                helpIndex = helpIndex + strDigit;  
            }
            
            answer = Convert.ToInt32(helpIndex,2);
            Console.WriteLine(answer);
        }

    }
