﻿using System;  
    class DecimalToHexadecimalNumber
    {
        static void Main()
        {
            long input = long.Parse(Console.ReadLine());
            string output = null;
            long howManySixteens = 1;
            long diff = input;
            byte middleResult = 0;

            while (input / howManySixteens > 16)
            {
                howManySixteens = howManySixteens * 16;  
            }
            
            while (diff > 0)
            {
                middleResult = (byte)(diff / howManySixteens);

                switch (middleResult)
                {
                    case 10: output = output + "A"; break;
                    case 11: output = output + "B"; break;
                    case 12: output = output + "C"; break;
                    case 13: output = output + "D"; break;
                    case 14: output = output + "E"; break;
                    case 15: output = output + "F"; break;
                    default: output = output + middleResult; break;
                }

                diff = diff - howManySixteens*middleResult;
                howManySixteens = howManySixteens / 16;                  
            }

            Console.WriteLine(output);
        }
    }

