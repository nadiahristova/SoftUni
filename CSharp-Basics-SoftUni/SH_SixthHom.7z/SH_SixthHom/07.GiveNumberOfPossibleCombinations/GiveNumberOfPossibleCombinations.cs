﻿using System;

    class GiveNumberOfPossibleCombinations
    {
        static void Main()
        {
            Console.Write("n = ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("k = ");
            int k = int.Parse(Console.ReadLine());

            ConsoleKeyInfo key;

            while (!(1 < k && k < n && n < 100))
            {
                Console.WriteLine("False Input. Please try again(1 < k < n < 100). Press ESC for exit or any other key to continue.");
                key = Console.ReadKey();
                if (key.Key == ConsoleKey.Escape)
                {
                    Console.WriteLine();
                    return;
                }
                else
                {
                    Console.Clear();
                    Console.Write("n = ");
                    n = int.Parse(Console.ReadLine());
                    Console.Write("k = ");
                    k = int.Parse(Console.ReadLine());
                }
            }

            int diff = n - k;             
            double division = 1;

            for (int i = 0; i < diff; i++)
            {                  
                division = division * (n - diff + i + 1) / (diff - i);
            }

            Console.WriteLine(division);
        }
    }

