﻿using System;

class PrintADeckOf52Cards
{
    static void Main()
    {
        string club = "\u2660";
        string diamond = ((char)9830).ToString();
        string heart = "\u2665";
        string spade = ((char)9827).ToString();
        string[] card = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };        

        for (int i = 0; i < 13; i++)
        {        
            for (int suit = 0; suit < 4; suit++)
            {
                switch (suit)
                {
                    case 0: Console.Write(card[i] + spade + " "); break;
                    case 1: Console.Write(card[i] + diamond + " "); break;
                    case 2: Console.Write(card[i] + heart + " "); break;
                    case 3: Console.Write(card[i] + club); break; 
                }
            } 

            Console.WriteLine();
        } 
    }
}
