﻿using System;

    class CalculateGCD
    {
        static void Main()
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int diff, maxDivider, neutral; 
            int wholeDivision;
            if (a>=b)
            {
                diff = b;
                maxDivider = a;
            }
            else
            {
                diff = a;
                maxDivider = b;
            }

            do
            {   
                wholeDivision = maxDivider / diff;
                neutral = diff;
                diff = maxDivider - wholeDivision * diff;
                maxDivider = neutral; 
            } while (diff != 0);

            Console.WriteLine("GCD({0},{1})={2}", a, b, neutral);
        }
    }

