﻿using System;
using System.Globalization;

    class ExamSchedule
    {
        static void Main()
        {
            byte startingHour = byte.Parse(Console.ReadLine());
            byte startingMinutes = byte.Parse(Console.ReadLine());
            string partOfTheDay = Console.ReadLine();
            byte durationHours = byte.Parse(Console.ReadLine());
            byte durationMinutes = byte.Parse(Console.ReadLine());
         
            DateTime StartExam = new DateTime();
            DateTime EndExam = new DateTime();
            StartExam = DateTime.Parse(startingHour + ":" + startingMinutes + " " + partOfTheDay);
            EndExam = StartExam.AddHours(durationHours).AddMinutes(durationMinutes);
            Console.WriteLine(EndExam.ToString("hh:mm:tt", CultureInfo.InvariantCulture)); 
        }
    }

