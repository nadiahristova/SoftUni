﻿using System;
using System.Numerics;

    class TrailingZeroesInNFactorial
    {
        static void Main()
        {
            int input = int.Parse(Console.ReadLine());
            BigInteger nFactorial = 1;
            int zeroCounter = 0;

            for (int i = 2; i <= input; i++)
            {
                nFactorial = nFactorial * i; 
            }
                         
            while (nFactorial % 10 == 0)
            {
               nFactorial = nFactorial / 10;
               zeroCounter++;
            }

            Console.WriteLine(zeroCounter);
        }
    }
