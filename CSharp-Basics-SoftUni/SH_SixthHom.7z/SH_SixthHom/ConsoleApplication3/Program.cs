﻿
    
using System;
 
class SpiralMatrix
{
    static void Main()
    {
        Console.SetBufferSize(300, 400);
        //Input
        int n;
        Console.Write("n=");
        while (!int.TryParse(Console.ReadLine(), out n) || n < 1)
        {
            Console.WriteLine("Wrong input (integer n>=1)");
            Console.Write("n=");
        }
        //Create SpiralMatrix
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                int CurrentCircleI;
                int CurrentInCyrcleJ;
                int MinCircles;
 
                if ((i + 1) <= (n + 1) / 2)
                {
                    CurrentCircleI = i + 1;
                    if ((j+1)<=(n+1)/2)
                    {
                        CurrentInCyrcleJ = j + 1;
                    }
                    else
                    {
                        CurrentInCyrcleJ = n - j;
                    }
                }
                else
                {
                    CurrentCircleI = n - i;
                    if ((j + 1) <= (n + 1) / 2)
                    {
                        CurrentInCyrcleJ = j + 1;
                    }
                    else
                    {
                        CurrentInCyrcleJ = n - j;
                    }
                }
 
                MinCircles = Math.Min(CurrentCircleI, CurrentInCyrcleJ);
                int PrintNumber=-1;
                int CurrentCount = 1;
                int k = 0;
                for (int circle = 1; circle < MinCircles; circle++)
                {
                    CurrentCount += 4 * (n - k) - 4;
                    k += 2;
                }
                if (j >= i && i < n - j)
                {
                    PrintNumber = CurrentCount + j - i; //PrintNumber = 0;
                }
                else if (j >= (n + 1) / 2 && j - i > 0)
                {
                    PrintNumber = CurrentCount + n - k + i - MinCircles; //PrintNumber = 1;
                }
                else if (j <= i && i >= n - j)
                {
                    PrintNumber = CurrentCount + i - j + 2 * (n - 2 * MinCircles) + 2; //PrintNumber = 2;
                }
                else if (j < i && i < n - j)
                {
                    CurrentCount += 4 * (n - k) - 4;
                    PrintNumber = CurrentCount - i + j; //PrintNumber = 3;
                }
                Console.Write("{0,5}", PrintNumber);
            }
            Console.WriteLine();
        }
    }
}
