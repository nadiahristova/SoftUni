﻿using System;
using System.Linq;
using System.Collections.Generic;

    class FiveSpecialLetters
    {
        static void Main()
        {
            int start = int.Parse(Console.ReadLine());
            int end = int.Parse(Console.ReadLine());
            char[] letterArr = { 'a', 'b', 'c', 'd', 'e' };
            int[] weightOfLetters = { 5, -12, 47, 7, -32 };
            string answer = null;
            int weight = 0;
            bool answerExists = false;
            int[] inputArr = new int[5];

            for (int i = 0; i < 5; i++)
            {           
                inputArr[0]=i;
                for (int j = 0; j < 5; j++)
                {                         
                    inputArr[1]=j;
                    for (int k = 0; k < 5; k++)
                    {                              
                        inputArr[2]=k;
                        for (int q = 0; q < 5; q++)
                        {                                 
                            inputArr[3]=q;
                               for (int l = 0; l < 5; l++)
                                {                                       
                                    inputArr[4]=l;
                                    List<int> charSequence = new List<int>();
                                    for (int w = 0; w < 5; w++)
                                    {
                                        charSequence.Add(inputArr[w]);
                                    }

                                    List<int> noDupesList = new List<int>();
                                    noDupesList = charSequence.Distinct().ToList();

                                    weight = 0;

                                    for (int p = 1; p <= noDupesList.Count; p++)
                                    {
                                        weight = weight + p * weightOfLetters[noDupesList[p - 1]];
                                    }

                                    if (weight >= start && weight <= end)
                                    {
                                        string help = null;

                                        foreach (var item in charSequence)
                                        {
                                            help = help + letterArr[item];
                                        }
                                        Console.Write(help + " ");
                                        answerExists = true;
                                    }                                        
                                }
                        }
                    }
                }
            }

            if (!answerExists)
            {
                Console.WriteLine("No");
            }              
        }
    }

