﻿using System;

    class OddAndEvenProduct
    {
        static void Main()
        {
            Console.Write("Please enter a sequence of numbers: ");
            string sequenceOfNumbers = Console.ReadLine();
            string[] strSingleNums = sequenceOfNumbers.Split(' ');
            int[] singleNums = new int[strSingleNums.Length];
            int oddProduct = 1;
            int evenProduct = 1;
            
            for (int i = 0; i < strSingleNums.Length; i++)
            {
                 singleNums[i] = int.Parse(strSingleNums[i]);
                 if (i%2 != 0)
                 {
                     evenProduct = evenProduct * singleNums[i];
                 }
                 else oddProduct = oddProduct * singleNums[i];
            }

            if (oddProduct == evenProduct)
            {
                Console.WriteLine("yes \nproduct = {0}", oddProduct ); 
            } else
	            {
                    Console.WriteLine("no \nodd_product = {0} \neven_product = {1}", oddProduct, evenProduct );
	            }
        }
    }

