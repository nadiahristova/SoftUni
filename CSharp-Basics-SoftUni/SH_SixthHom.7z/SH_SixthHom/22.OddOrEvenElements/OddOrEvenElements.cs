﻿using System;
using System.Globalization;
using System.Threading;   
    class OddOrEvenElements
    {
        static void Main()
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            string nNumbersInput = Console.ReadLine();
            string[] answers = { "No", "No", "No", "No", "No", "No" };
            decimal OddSum = 0;
            decimal OddMin = decimal.MaxValue;
            decimal OddMax = decimal.MinValue;
            decimal EvenSum = 0;
            decimal EvenMin = decimal.MaxValue;
            decimal EvenMax = decimal.MinValue;


            string[] strNumbers = nNumbersInput.Split(' ');
            decimal[] intNNumbers = new decimal[strNumbers.Length];

            if (nNumbersInput != string.Empty)
            {   
                for (int i = 0; i < strNumbers.Length; i++)
                {
                    intNNumbers[i] = decimal.Parse(strNumbers[i]);
                }

                for (int i = 1; i <= intNNumbers.Length; i++)
                {
                    if (i % 2 != 0)
                    {
                        if (OddMax <= intNNumbers[i - 1])
                        {
                            OddMax = intNNumbers[i - 1];
                            answers[2] = ((double)OddMax).ToString();
                        }

                        if (OddMin >= intNNumbers[i - 1])
                        {
                            OddMin = intNNumbers[i - 1];
                            answers[1] = ((double)OddMin).ToString();
                        }

                        OddSum = OddSum + intNNumbers[i - 1];
                        answers[0] = ((double)OddSum).ToString();
                    }
                    else
                    {
                        if (EvenMax <= intNNumbers[i - 1])
                        {
                            EvenMax = intNNumbers[i - 1];
                            answers[5] = ((double)EvenMax).ToString();
                        }

                        if (EvenMin >= intNNumbers[i - 1])
                        {
                            EvenMin = intNNumbers[i - 1];
                            answers[4] = ((double)EvenMin).ToString();
                        }

                        EvenSum = EvenSum + intNNumbers[i - 1];
                        answers[3] = ((double)EvenSum).ToString();
                    }
                }                 
            }
            Console.WriteLine("OddSum={0}, OddMin={1}, OddMax={2}, EvenSum={3}, EvenMin={4}, EvenMax={5}", answers[0], answers[1], answers[2], answers[3], answers[4], answers[5]);
        }
    }

