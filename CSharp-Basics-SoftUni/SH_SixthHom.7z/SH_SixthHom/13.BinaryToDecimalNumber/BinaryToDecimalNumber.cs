﻿using System;

    class BinaryToDecimalNumber
    {
        static void Main()
        {
            string strInput = Console.ReadLine();               
            long answer = 0;
            string strNumber;
            int power = 2;

            for (int i = strInput.Length - 2; i >= 0; i--)
            {
                strNumber = strInput[i].ToString();
                answer = answer + power * int.Parse(strNumber);
                power = power * 2;                   
            }

            strNumber = strInput[strInput.Length - 1].ToString();
            if (strNumber == "1")
            {
                answer++;
            }

            Console.WriteLine(answer);   
        }
    }

