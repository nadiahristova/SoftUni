﻿using System;

    class PrintADeckOf52Cards
    {
        static void Main()
        {
            string club = "\u2660";
            string diamond = ((char)9830).ToString();
            string heart = "\u2665";
            string spade = ((char)9827).ToString();
            string card = null;             

            for (int i = 2; i <= 14; i++)
            {
                string roll = null;

                switch (i)
                    {
                        case 11: card = "J"; break;
                        case 12: card = "Q"; break;
                        case 13: card = "K"; break;
                        case 14: card = "A"; break;
                        default: card = i.ToString();  break;
                    } 
                for (int suit = 0; suit < 4; suit++)
                {
                    switch (suit)
                    {
                        case 0: roll = card + spade + " "; break;
                        case 1: roll = roll + card + diamond + " "; break;
                        case 2: roll = roll + card + heart + " "; break;
                        case 3: roll = roll + card + club; break;
                        
                    } 
                }

                Console.WriteLine(roll);
            }

            
        }
    }

