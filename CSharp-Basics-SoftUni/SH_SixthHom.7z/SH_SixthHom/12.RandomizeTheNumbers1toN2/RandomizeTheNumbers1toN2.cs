﻿using System;
using System.Collections.Generic;

    class RandomizeTheNumbers1toN2
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            List<int> outputOrder = new List<int>();
            Random ranGenerator = new Random();             

            for (int i = 1; i <= n; i++)
            {
                int randomPos = ranGenerator.Next(0, outputOrder.Count+1);
                outputOrder.Insert(randomPos, i);
            }

            foreach (var number in outputOrder)
            {
                Console.Write("{0} ", number);
            }
            Console.WriteLine();
        }
    }

