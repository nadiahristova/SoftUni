﻿using System;

class SumOf5Numbers
{
    static void Main()
    {
       double p = 21.256;
       string answer = p.ToString(".##");
    }
}