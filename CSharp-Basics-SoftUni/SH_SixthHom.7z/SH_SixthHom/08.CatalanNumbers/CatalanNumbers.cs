﻿using System;

    class CatalanNumbers
    {
        static void Main()
        {
            Console.Write("n = ");
            int n = int.Parse(Console.ReadLine());
           
            ConsoleKeyInfo key;

            while (!( n >= 0))
            {
                Console.WriteLine("False Input. Please try again(n>=0). Press ESC for exit or any other key to continue.");
                key = Console.ReadKey();
                if (key.Key == ConsoleKey.Escape)
                {
                    Console.WriteLine();
                    return;
                }
                else
                {
                    Console.Clear();
                    Console.Write("n = ");
                    n = int.Parse(Console.ReadLine());                    
                }
            }
                        
            double divide = 1;

            for (int i = 1; i <= n - 1; i++)
            {
                divide = divide * (n + i+1) / (i+1);
            }
            Console.WriteLine(divide);
        }
    }

