﻿using System;

    class MinMaxSumAndAverageOfNNumbers
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int min = int.MaxValue;
            int max = int.MinValue;
            int sum = 0;             

            for (int i = 0; i < n; i++)
            {
                int num = int.Parse(Console.ReadLine());

                if (num > max)
                {
                    max = num;
                }
                if (num < min)
                {
                    min = num; 
                }

                sum = sum + num;
            }

            Console.WriteLine("min = {0} \nmax = {1} \nsum = {2} \navg = {3:0.00}", min, max, sum, sum*1.0/n );
        }
    }

