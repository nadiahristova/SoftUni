﻿using System;

class SpiralMatrix
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        string powNum = Convert.ToString(n * n);
        int digitCounter = powNum.Length;
        int numCounter = 1;
        int plusOrMinusAxisDirection = 0;
        sbyte direction = 1;
        double i = n;
        int x = 0;
        int y = 0;
        Console.Clear();

        do
        {
            for (int j = 1; j <= (int)i; j++)
            {
                if (plusOrMinusAxisDirection == 2)
                {
                    plusOrMinusAxisDirection = 0;
                    direction = (sbyte)(direction * (-1));
                }

                if (i % 1 == 0)
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write(numCounter.ToString().PadRight(digitCounter, ' ') + " ");

                    if (j != (int)i)
                    {
                        x = x + direction * digitCounter + direction * 1;

                    }
                }
                else
                {
                    y = y + direction * 1;

                    Console.SetCursorPosition(x, y);
                    Console.Write(numCounter.ToString().PadRight(digitCounter, ' ') + " ");

                    if (j == (int)i)
                    {
                        x = x + (-1) * direction * digitCounter + (-1) * direction;
                    }
                }

                numCounter++;
            }

            Console.WriteLine();
            plusOrMinusAxisDirection++;
            i -= 0.5;
        } while (i >= 0);
        Console.SetCursorPosition(0, Console.WindowHeight -1);
    }
}

