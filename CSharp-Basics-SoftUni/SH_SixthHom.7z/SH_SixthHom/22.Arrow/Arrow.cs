﻿using System;
    class Arrow
    {
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            string roll = null;
            int helpDecrese = n + (2 * ((n - 2) / 2) - 2);
            
            for (int i = 1; i <= 2*n-1; i++)
            {
                if (i==1)
                {
                    roll = new string('.', n / 2) + new string('#', n) + new string('.', n / 2);
                } 
                else if (i<n)
                {
                    roll = new string('.', n / 2) + "#" + new string('.', n-2)  + "#" + new string('.', n / 2);
                }
                else if (i==n)
                {
                    roll = new string('#', (n / 2) + 1) + new string('.', n - 2) + new string('#', n / 2 + 1);
                }
                else if (i == 2 * n - 1)
                {
                    roll = new string('.', n - 1) + "#" + new string('.', n - 1);
                }
                else
                {
                    roll = new string('.', i - n) + "#" + new string('.', helpDecrese) + "#" + new string('.', i - n);
                    helpDecrese -= 2;
                }
                Console.WriteLine(roll); 
            }

        }
    }

