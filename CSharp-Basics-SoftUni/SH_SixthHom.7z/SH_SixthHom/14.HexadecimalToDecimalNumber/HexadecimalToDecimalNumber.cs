﻿using System;

    class HexadecimalToDecimalNumber
    {
        static void Main()
        {
            string input = Console.ReadLine();
            long output = 0;
            long sixteenPower = 1;

            for (int i = 0; i < input.Length-1; i++)
            {
                sixteenPower = 16 * sixteenPower; 
            }

            for (int i = 0; i < input.Length; i++)
            {
                output = output + sixteenPower * returnValue(input[i].ToString());
                sixteenPower = sixteenPower / 16;                  
            }

            Console.WriteLine(output);
        }

        static int returnValue (string digit)
        {
            int validDigit = 0;
            bool isInt = int.TryParse(digit, out validDigit);

            if (isInt)
            {
               return validDigit; 
            }  
            else
	        {
              switch (digit)
	            {
                  case "A": validDigit = 10; break;
                  case "a": validDigit = 10; break;
                  case "B": validDigit = 11; break;
                  case "b": validDigit = 11; break;
                  case "C": validDigit = 12; break;
                  case "c": validDigit = 12; break;
                  case "D": validDigit = 13; break;
                  case "d": validDigit = 13; break;
                  case "E": validDigit = 14; break;
                  case "e": validDigit = 14; break;
                  case "F": validDigit = 15; break;
                  case "f": validDigit = 15; break;  
	            }
                return validDigit;
	        }
        }
    }

