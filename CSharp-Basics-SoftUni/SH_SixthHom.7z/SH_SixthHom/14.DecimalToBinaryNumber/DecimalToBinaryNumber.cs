﻿using System;

    class DecimalToBinaryNumber
    {
        static void Main()
        {
            long input = long.Parse(Console.ReadLine());
            long smallerNum = 1;
            long difference = input;
            string output = null;
            long helpNum = 0;
                                         
                while (input /smallerNum > 1)
                {
                    smallerNum = smallerNum * 2;
                }            

                do
                {
                    if (smallerNum != 0)
                    {
                        helpNum = (difference / smallerNum);
                    }
  
                    if (helpNum == 1)
                    {
                        difference = difference - smallerNum;
                        output = output + "1";                   
                    }
                    else
                    {
                        output = output + "0";                                               
                    }
                    smallerNum = smallerNum / 2;
                                                                       
                } while (smallerNum > 0);

                Console.WriteLine(output);
        }
    }

