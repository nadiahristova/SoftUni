﻿using System;

    class BitRoller
    {
        static void Main()
        {
            // 80% true :)
            uint n = uint.Parse(Console.ReadLine());
            int f = int.Parse(Console.ReadLine());
            int r = int.Parse(Console.ReadLine());              
            uint result = n;               

            for (int i = 0; i < r; i++)
			{
			    uint leftSide = result >> f+1;                   
                //Console.WriteLine(Convert.ToString(leftSide,2));
                uint mask = 1;
                for (int j = 0; j < f-2; j++)
			    {
                    mask = mask << 1;
                    mask = mask | 1;           
			    }   
                //Console.WriteLine(Convert.ToString(mask, 2));
                uint rightSide = (result >> 1) & mask;
                //Console.WriteLine(Convert.ToString(rightSide,2));
                uint lastDigit = (byte)(result & 1);
                uint digitBeforeF = (byte)(leftSide & 1);
                uint digitAtFPosition = (byte)((result >> f) & 1);
                uint helperWithInsertingGivenDigit = digitBeforeF << (f - 1);
                if (f == 18)
                {
                    helperWithInsertingGivenDigit = lastDigit << 17;
                    //Console.WriteLine(Convert.ToString(helperWithInsertingGivenDigit, 2));
                    rightSide = (rightSide) | helperWithInsertingGivenDigit;
                    //Console.WriteLine(Convert.ToString(rightSide, 2));
                    result = (digitAtFPosition << f) | (rightSide);
                    //Console.WriteLine(Convert.ToString(result, 2));                       
                }
                else if (f == 0)
                {
                    uint bit = (leftSide & 1);
                    leftSide = leftSide >> 1;
                    leftSide = (leftSide << 1) | lastDigit;
                    Console.WriteLine(Convert.ToString(leftSide, 2));
                    result = (bit << 18) | (leftSide);
                    Console.WriteLine(Convert.ToString(result, 2));    
                } 
                else
                {
                    rightSide = rightSide | helperWithInsertingGivenDigit;
                    //Console.WriteLine(Convert.ToString(rightSide, 2));
                    helperWithInsertingGivenDigit = lastDigit << (17 - f);
                    leftSide = (leftSide >> 1) | helperWithInsertingGivenDigit;
                    //Console.WriteLine(Convert.ToString(leftSide, 2));
                    result = (leftSide << 1) | digitAtFPosition;                      
                    result = (result << f) | rightSide;
                   // Console.WriteLine(Convert.ToString(result, 2));
                }
			}
            Console.WriteLine(result);
        }
    }

