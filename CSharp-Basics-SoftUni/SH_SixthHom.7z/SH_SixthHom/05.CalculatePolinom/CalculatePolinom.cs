﻿using System;

    class CalculatePolinom
    {
        static void Main()
        {
           int n = int.Parse(Console.ReadLine());
           int x = int.Parse(Console.ReadLine());

           double sum = 1;
           double newMember = 1;           

           for (int i = 1; i <= n; i++)
           {
               newMember = newMember * 1.0 * i / x;
               sum = sum + newMember; 
           }

           Console.WriteLine("{0:f5}",sum);
        }
    }

