﻿using System;

    class RandomizeTheNumbers1ToN
    {
        static void Main()
        {
            Console.Write("n = ");
            int n = int.Parse(Console.ReadLine());
            string output = null;
            bool existing;

            Random gen = new Random();

            int randomNum = gen.Next(1, n + 1);
            output = randomNum.ToString();
            
            for (int i = 1; i < n; i++)
            {                   
                do
                {
                    existing = false;
                    randomNum = gen.Next(1, n + 1);
                    string[] numSequence = output.Split(' ');
                    int[] numArr = new int[numSequence.Length];

                    for (int j = 0; j < numSequence.Length; j++)
                    {
                        numArr[j] = int.Parse(numSequence[j]);
                        if (numArr[j] == randomNum)
                        {
                            existing = true;
                            break;
                        }                        
                    } 

                } while (existing == true);

                output = output + " "+randomNum.ToString();               
            }

            Console.WriteLine(output);
        }
    }

