﻿using System;

    class BitRoller_3
    {
        const int size = 19;
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int pillarPosition = int.Parse(Console.ReadLine());
            int rolls = int.Parse(Console.ReadLine());

            for (int i = 0; i < rolls; i++)
            {        
            int result = 0;
            for (int pos = 0; pos < size; pos++)
            {                    
                int bit = (n >> pos) & 1;
                if (pos == pillarPosition)
                {
                    result = result | (bit << pos);
                }
                else
                {
                    int newPos = RightPosition(pos);
                    if (newPos == pillarPosition)
                    {
                        newPos = RightPosition(newPos); 
                    }
                    result = result | (bit << newPos);
                    n = result;
                }
             }
            }

            Console.WriteLine(n);
        }

        static int RightPosition(int pos)
        {
            int newPos = pos - 1;
            if (newPos <0)
            {
                newPos = size - 1; 
            }
            return newPos;
        }
    }
