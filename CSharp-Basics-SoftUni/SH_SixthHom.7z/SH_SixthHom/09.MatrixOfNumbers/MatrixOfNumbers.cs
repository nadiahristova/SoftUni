﻿using System;

class MatrixOfNumbers
{
    static void Main()
    {
        Console.WriteLine("Please type in (1 ≤ n ≤ 20).");         
        Console.Write("n=");
        int n = int.Parse(Console.ReadLine());
        int maxNum = 2 * n - 1;
        int howManyDigitsMaxNum = maxNum.ToString().Length;         
        int memberOfMatrix = 0;

        for (int i = 1; i <= n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                memberOfMatrix++;
                int howManyDigitsInMembOfMatrix = memberOfMatrix.ToString().Length;
                Console.Write("{0} ", memberOfMatrix.ToString().PadRight(howManyDigitsMaxNum - howManyDigitsInMembOfMatrix+1, ' ')); 
            }
            memberOfMatrix = i;
            Console.WriteLine();
        } 
    }
}
